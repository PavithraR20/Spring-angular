export class Event {
  id: number=0;         // Optional
  name: string=" ";       // Event name
  startTime: number=0;  // Event start time (0-23)
  endTime: number=0;    // Event end time (1-24)
}