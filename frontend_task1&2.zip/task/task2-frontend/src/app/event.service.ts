import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  private baseURL = "http://localhost:8080/api/v1/events";

  constructor(private httpClient: HttpClient) { }

  // Method to get all events
  getEventsList(): Observable<Event[]> {
    return this.httpClient.get<Event[]>(`${this.baseURL}`);
  }
}
