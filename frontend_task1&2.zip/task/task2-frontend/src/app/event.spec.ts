import { Event } from './event';

describe('Events', () => {
  it('should create an instance', () => {
    expect(new Event()).toBeTruthy();
  });
});
