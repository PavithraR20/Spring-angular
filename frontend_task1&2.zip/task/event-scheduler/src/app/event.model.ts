export class Event {
    id?: number;
    name: string;
    startTime: number;
    endTime: number;


  
    constructor(name: string, startTime: number, endTime: number) {
      this.name = name;
      this.startTime = startTime;
      this.endTime = endTime;
    }

  }
  