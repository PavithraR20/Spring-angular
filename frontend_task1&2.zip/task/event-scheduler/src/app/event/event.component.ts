import { Component, OnInit } from '@angular/core';
import { SchedulerService } from '../scheduler.service';
import { Event } from '../event.model';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css'],
})
export class EventComponent implements OnInit {
  events: Event[] = [];

  constructor(private schedulerService: SchedulerService) {}

  ngOnInit(): void {
    this.getEvents();
  }

  // Fetch all events from the service
  getEvents(): void {
    this.schedulerService.getEvents().subscribe(
      (data) => {
        this.events = data;
      },
      (error) => {
        console.error('Error fetching events', error);
      }
    );
  }
}